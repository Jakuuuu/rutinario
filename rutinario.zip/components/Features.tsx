import React from 'react';

export const Features: React.FC = () => {
    return (
        <section id="como-funciona" className="py-20 bg-white dark:bg-card-dark transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-3xl mx-auto mb-16">
                    <h2 className="font-display text-4xl font-bold text-primary mb-4">Aprendizaje Visual y Táctil</h2>
                    <p className="text-lg text-gray-600 dark:text-gray-300">
                        Rutinario transforma las mañanas caóticas en juegos divertidos. El sistema está diseñado para que los niños tomen el control.
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                    {/* Feature 1 */}
                    <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border-b-4 border-primary hover:transform hover:-translate-y-2 transition duration-300">
                        <div className="w-14 h-14 bg-orange-100 dark:bg-orange-900/40 rounded-full flex items-center justify-center text-primary mb-6">
                            <span className="material-icons-round text-3xl">dashboard</span>
                        </div>
                        <h3 className="font-display text-2xl font-bold mb-3 dark:text-white">8 Tareas Diarias</h3>
                        <p className="text-gray-600 dark:text-gray-300">Un espacio limitado para no abrumar. Enfócate en los momentos clave del día: Mañana, Tarde o Noche.</p>
                    </div>

                    {/* Feature 2 */}
                    <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border-b-4 border-secondary hover:transform hover:-translate-y-2 transition duration-300">
                        <div className="w-14 h-14 bg-green-100 dark:bg-green-900/40 rounded-full flex items-center justify-center text-secondary mb-6">
                            <span className="material-icons-round text-3xl">style</span>
                        </div>
                        <h3 className="font-display text-2xl font-bold mb-3 dark:text-white">100+ Actividades</h3>
                        <p className="text-gray-600 dark:text-gray-300">Desde "Lavarse los dientes" hasta "Tiempo en familia". Tarjetas ilustradas para cada necesidad del hogar.</p>
                    </div>

                    {/* Feature 3 */}
                    <div className="bg-background-light dark:bg-background-dark p-8 rounded-2xl border-b-4 border-blue-400 hover:transform hover:-translate-y-2 transition duration-300">
                        <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center text-blue-500 mb-6">
                            <span className="material-icons-round text-3xl">touch_app</span>
                        </div>
                        <h3 className="font-display text-2xl font-bold mb-3 dark:text-white">Sistema "Flip"</h3>
                        <p className="text-gray-600 dark:text-gray-300">La satisfacción inmediata de voltear la tarjeta y ver el check verde ✔️ refuerza el hábito positivo.</p>
                    </div>
                </div>
            </div>
        </section>
    );
};