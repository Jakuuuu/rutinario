import React from 'react';

export const Footer: React.FC = () => {
    return (
        <footer className="bg-background-light dark:bg-background-dark pt-16 pb-8 border-t border-gray-200 dark:border-gray-800 transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-4 gap-8 mb-12">
                    
                    <div className="col-span-1 md:col-span-1">
                        <div className="flex items-center gap-2 mb-4">
                            <span className="material-icons-round text-primary text-3xl">schedule</span>
                            <span className="font-display font-semibold text-xl text-primary">Rutinario</span>
                        </div>
                        <p className="text-gray-500 dark:text-gray-400 text-sm">
                            Ayudando a niños extraordinarios a construir hábitos ordinarios de forma divertida.
                        </p>
                    </div>

                    <div>
                        <h4 className="font-bold text-gray-900 dark:text-white mb-4">Producto</h4>
                        <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                            <li><a href="#" className="hover:text-primary transition">El Kit Rutinario</a></li>
                            <li><a href="#" className="hover:text-primary transition">Paquetes de Extensión</a></li>
                            <li><a href="#" className="hover:text-primary transition">Descargables</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-gray-900 dark:text-white mb-4">Recursos</h4>
                        <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                            <li><a href="#" className="hover:text-primary transition">Blog para Padres</a></li>
                            <li><a href="#" className="hover:text-primary transition">Guía de Uso</a></li>
                            <li><a href="#" className="hover:text-primary transition">Preguntas Frecuentes</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-gray-900 dark:text-white mb-4">Contacto</h4>
                        <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                            <li className="flex items-center gap-2"><span className="material-icons-round text-sm">email</span> hola@rutinario.com</li>
                            <li className="flex items-center gap-2"><span className="material-icons-round text-sm">phone</span> +1 (555) 123-4567</li>
                            <li className="flex gap-4 mt-4">
                                <a href="#" className="text-gray-400 hover:text-primary transition">Instagram</a>
                                <a href="#" className="text-gray-400 hover:text-primary transition">Facebook</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500 dark:text-gray-500">
                    <p>© 2023 Rutinario. Todos los derechos reservados.</p>
                    <div className="flex gap-4 mt-4 md:mt-0">
                        <a href="#" className="hover:text-gray-800 dark:hover:text-gray-300">Privacidad</a>
                        <a href="#" className="hover:text-gray-800 dark:hover:text-gray-300">Términos</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};