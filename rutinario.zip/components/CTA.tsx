import React from 'react';

export const CTA: React.FC = () => {
    return (
        <section className="py-24 bg-white dark:bg-card-dark transition-colors duration-300">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="bg-primary rounded-3xl p-8 md:p-16 text-center shadow-2xl relative overflow-hidden">
                    {/* Decorative Blobs */}
                    <div className="absolute top-0 left-0 w-64 h-64 bg-white opacity-10 rounded-full -translate-x-1/2 -translate-y-1/2"></div>
                    <div className="absolute bottom-0 right-0 w-40 h-40 bg-white opacity-10 rounded-full translate-x-1/3 translate-y-1/3"></div>
                    
                    <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">¿Listo para empezar la rutina?</h2>
                    <p className="text-orange-50 text-xl mb-10 max-w-2xl mx-auto">
                        Únete a miles de familias que han encontrado la paz y la organización gracias a Rutinario. Incluye tablero magnético, 100 tarjetas y guía para padres.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <a href="#" className="bg-white text-primary px-10 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl hover:bg-gray-50 transition transform hover:-translate-y-1">
                            Comprar Kit Rutinario ($39.99)
                        </a>
                    </div>
                    
                    <p className="text-orange-100 text-sm mt-6 flex justify-center items-center gap-2">
                        <span className="material-icons-round text-sm">local_shipping</span> Envío gratis a todo el país
                    </p>
                </div>
            </div>
        </section>
    );
};