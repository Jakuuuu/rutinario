import React from 'react';
import { RoutineItem } from '../types';

interface FlipCardProps {
    item: RoutineItem;
    onToggle: (id: number) => void;
}

export const FlipCard: React.FC<FlipCardProps> = ({ item, onToggle }) => {
    return (
        <div 
            className="perspective-1000 h-[180px] w-full cursor-pointer group"
            onClick={() => onToggle(item.id)}
        >
            <div className={`relative w-full h-full text-center transition-transform duration-700 transform-style-3d ${item.isCompleted ? 'rotate-y-180' : ''}`}>
                {/* Front */}
                <div className="absolute inset-0 w-full h-full backface-hidden bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-2xl shadow-sm flex flex-col justify-center items-center p-2">
                    <span className="text-5xl mb-2">{item.emoji}</span>
                    <p className="font-bold text-gray-700 dark:text-gray-200 text-sm">{item.label}</p>
                </div>

                {/* Back */}
                <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 bg-secondary border-2 border-green-600 rounded-2xl shadow-sm flex flex-col justify-center items-center">
                    <span className="material-icons-round text-white text-6xl">check_circle</span>
                </div>
            </div>
        </div>
    );
};