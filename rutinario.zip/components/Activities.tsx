import React from 'react';

const ACTIVITIES = [
    { icon: '🚿', label: 'Ducharse' },
    { icon: '🧸', label: 'Recoger' },
    { icon: '📚', label: 'Leer' },
    { icon: '😴', label: 'Dormir' },
    { icon: '🐕', label: 'Pasear perro' },
    { icon: '🍎', label: 'Merendar' },
];

export const Activities: React.FC = () => {
    return (
        <section id="actividades" className="py-20 bg-primary bg-opacity-5 dark:bg-opacity-10 transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-end mb-12">
                    <div>
                        <h2 className="font-display text-4xl font-bold text-gray-900 dark:text-white">Explora las Fichas</h2>
                        <p className="mt-2 text-gray-600 dark:text-gray-400">Incluye fichas para higiene, tareas, juegos y emociones.</p>
                    </div>
                    <a href="#" className="hidden sm:inline-block bg-white dark:bg-card-dark text-primary px-6 py-2 rounded-full font-bold shadow-sm hover:shadow-md transition">Ver todas</a>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {ACTIVITIES.map((act, idx) => (
                        <div key={idx} className="bg-white dark:bg-card-dark rounded-xl p-4 text-center shadow-sm hover:shadow-md transition border border-gray-100 dark:border-gray-700">
                            <span className="text-3xl block mb-2">{act.icon}</span>
                            <span className="text-sm font-bold text-gray-700 dark:text-gray-200">{act.label}</span>
                        </div>
                    ))}
                </div>

                <div className="mt-8 text-center sm:hidden">
                    <a href="#" className="inline-block bg-white dark:bg-card-dark text-primary px-6 py-2 rounded-full font-bold shadow-sm hover:shadow-md transition">Ver todas las fichas</a>
                </div>
            </div>
        </section>
    );
};