import React, { useState } from 'react';
import { FlipCard } from './FlipCard';
import { RoutineItem } from '../types';

const INITIAL_ITEMS: RoutineItem[] = [
    { id: 1, emoji: '🦷', label: 'Cepillar Dientes', isCompleted: true },
    { id: 2, emoji: '👕', label: 'Vestirse', isCompleted: true },
    { id: 3, emoji: '🎒', label: 'Mochila Lista', isCompleted: false },
    { id: 4, emoji: '🥣', label: 'Desayunar', isCompleted: false },
];

export const Hero: React.FC = () => {
    const [items, setItems] = useState<RoutineItem[]>(INITIAL_ITEMS);

    const toggleItem = (id: number) => {
        setItems(prev => prev.map(item => 
            item.id === id ? { ...item, isCompleted: !item.isCompleted } : item
        ));
    };

    return (
        <header className="relative overflow-hidden pt-12 pb-24 lg:pt-24">
            {/* Background Pattern */}
            <div className="absolute inset-0 z-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#D97757 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    
                    {/* Left Column: Content */}
                    <div>
                        <div className="inline-flex items-center px-3 py-1 rounded-full bg-orange-100 dark:bg-orange-900/30 text-primary font-bold text-sm mb-6">
                            <span className="material-icons-round text-sm mr-1">star</span> Nuevo Kit Educativo
                        </div>
                        <h1 className="font-display text-5xl lg:text-7xl font-bold leading-tight mb-6 text-gray-900 dark:text-white">
                            Construye hábitos <span className="text-primary">felices</span> cada día.
                        </h1>
                        <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 leading-relaxed max-w-lg">
                            Rutinario ayuda a los niños a desarrollar autonomía y funciones ejecutivas a través del juego. Organiza el día, reduce el estrés y celebra cada logro.
                        </p>
                        
                        <div className="flex flex-col sm:flex-row gap-4">
                            <a href="#" className="bg-primary hover:bg-orange-600 text-white text-center px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-orange-500/30 transition transform hover:-translate-y-1">
                                Conseguir mi Kit
                            </a>
                            <a href="#como-funciona" className="flex items-center justify-center gap-2 bg-white dark:bg-card-dark text-gray-700 dark:text-gray-200 px-8 py-4 rounded-xl font-bold text-lg shadow-md hover:shadow-lg transition border border-gray-100 dark:border-gray-700">
                                <span className="material-icons-round text-primary">play_circle_filled</span> Ver Video
                            </a>
                        </div>

                        {/* Social Proof */}
                        <div className="mt-10 flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex -space-x-2">
                                <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAaHsZqfoEoSHdADyjfVe2avOUFZvoEix7Qi5H1ijAabeVRQFhc7C7ltan7Ar5dXAbb3kyT9znyDNPU4OP8DjI5kceBXK_LtxMHsUrNUKV0QRSpgdHIFhj1Ny7d34SUr7B_gdADdfAx-npmXG_Txw3DB2iMJB31mWIVt2LhjHG43DX_uTmVYubq_sxOAys97iZEc1b69mfH4t5qI8yW51I33xvo0CYC1t_iBTLNIZios6cQaKCEejaSd0oHVj8e-jn4VrV6jzHCjiA" alt="User avatar" className="w-8 h-8 rounded-full border-2 border-white dark:border-background-dark" />
                                <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAbq_gm3tzSid4_nGvRbeR4ILBY4-daFZeidXsb4RVLIya7HJVTR6HwEeVn8GlzeVq21-dx5Kmtq7R5r2EHqbDyw8T8SEAf0RTU7qIr32GHir6xflxBeaPk9eYRXwy_FLPZUpoefU9O3r_6HkZGbi7ZBmltfWSDF-V-Rm_1Q0LQjhSVTDc1LE9uMDT1eaHvxFaxvQNg-e_NGHEW2mEZjN4K3p3PdLR4sLVmbD-NyUCr4dCQPGiSf6d_MFiSA8fgr77FWCs8hN7R-Ek" alt="User avatar" className="w-8 h-8 rounded-full border-2 border-white dark:border-background-dark" />
                                <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuDYhotHvst5FVG4ggxC7-1TlyouArz2F4mqS4rh_uAEvXqzZhmszNwPaqsXEw0WSiTFZrHTHQbho1xmiPKG54Ay3bJQouGS6EVDFj0W0MtDXozfaNl3fZ6KYkvCYqWDB3QPUjW11h36DjXm4PQD3uUnRSgBfIyQ-YCeO3HMYc21BFEkregST3qySdbhqUq8Xs1UqnLWNFQXoOfPiFovlXMkT6yPSaWnuCDr99QeQwPf_dLxZ4n5qcv1yN2agH09IuS34AXXVFqTNJc" alt="User avatar" className="w-8 h-8 rounded-full border-2 border-white dark:border-background-dark" />
                            </div>
                            <p>Aprobado por +1,000 padres felices</p>
                        </div>
                    </div>

                    {/* Right Column: Interactive Demo */}
                    <div className="relative mt-8 lg:mt-0">
                        <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full transform rotate-3"></div>
                        <div className="relative bg-white dark:bg-card-dark border-4 border-primary rounded-3xl p-6 shadow-2xl transform rotate-1">
                            <div className="bg-orange-100 dark:bg-orange-900/40 rounded-xl p-4 mb-6 flex justify-between items-center border border-primary/20">
                                <div className="flex items-center gap-2">
                                    <span className="material-icons-round text-primary text-3xl">alarm</span>
                                    <h3 className="font-display text-2xl font-bold text-primary">Mi Rutina Diaria</h3>
                                </div>
                                <span className="material-icons-round text-yellow-500 text-3xl">wb_sunny</span>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                {items.map(item => (
                                    <FlipCard key={item.id} item={item} onToggle={toggleItem} />
                                ))}
                            </div>

                            <div className="mt-4 text-center text-sm text-gray-400">
                                <span className="animate-pulse">👆 Haz clic en las tarjetas para completar la tarea</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </header>
    );
};