import React, { useState, useEffect } from 'react';

export const Navbar: React.FC = () => {
    const [isDark, setIsDark] = useState(false);

    // Initialize theme based on localStorage or system preference
    useEffect(() => {
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            setIsDark(true);
            document.documentElement.classList.add('dark');
        } else {
            setIsDark(false);
            document.documentElement.classList.remove('dark');
        }
    }, []);

    const toggleTheme = () => {
        if (isDark) {
            document.documentElement.classList.remove('dark');
            localStorage.theme = 'light';
            setIsDark(false);
        } else {
            document.documentElement.classList.add('dark');
            localStorage.theme = 'dark';
            setIsDark(true);
        }
    };

    return (
        <nav className="sticky top-0 z-50 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md border-b border-orange-100 dark:border-orange-900 transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-20 items-center">
                    <div className="flex items-center gap-2">
                        <span className="material-icons-round text-primary text-4xl">schedule</span>
                        <span className="font-display font-semibold text-2xl text-primary">Rutinario</span>
                    </div>
                    
                    <div className="hidden md:flex space-x-8">
                        <a href="#como-funciona" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary font-bold transition">Cómo Funciona</a>
                        <a href="#beneficios" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary font-bold transition">Beneficios</a>
                        <a href="#actividades" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary font-bold transition">Actividades</a>
                    </div>

                    <div className="flex items-center gap-4">
                        <button 
                            onClick={toggleTheme}
                            className="p-2 rounded-full hover:bg-orange-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300 transition"
                            aria-label="Toggle Dark Mode"
                        >
                            <span className="material-icons-round">{isDark ? 'light_mode' : 'dark_mode'}</span>
                        </button>
                        <a href="#" className="hidden sm:inline-block bg-primary hover:bg-orange-600 text-white px-6 py-2 rounded-full font-bold shadow-lg shadow-orange-500/30 transition transform hover:-translate-y-0.5">
                            Comprar Ahora
                        </a>
                    </div>
                </div>
            </div>
        </nav>
    );
};