import React from 'react';

export const Benefits: React.FC = () => {
    return (
        <section id="beneficios" className="py-20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1/3 h-full bg-orange-50 dark:bg-orange-900/10 -z-10 rounded-l-full"></div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-2 gap-16 items-center">
                    
                    {/* Image Column */}
                    <div className="order-2 md:order-1 relative group">
                        <img 
                            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDSEolTol1cLdMVWyIT_8czJOHyXxNi-fgECVVdmGFQis-346Z7asKSGZno6t_VOpsRyLQOYizQigF5_v-dTdc3P_Or9nH2iC3DWLENAEWcZCJYP-Unm_2JDmuX2NmNUz_atrWfC4HBtW8Ohs93azNLH-zU9Vq1mDCtwanB8QY3lGy6Pgu5BQIWzqYh9pFoBPuTWLOnXu_JJwoU-u1u_Qp91ZH45LRlafx4uGGvSkZuU9GOiNdfqHCUPDckGEtadDZftqhkr8qbfQo" 
                            alt="Child playing" 
                            className="rounded-3xl shadow-2xl rotate-2 group-hover:rotate-0 transition duration-500 object-cover" 
                        />
                        <div className="absolute -bottom-6 -left-6 bg-white dark:bg-card-dark p-6 rounded-2xl shadow-xl max-w-xs border border-gray-100 dark:border-gray-700">
                            <div className="flex items-center gap-3 mb-2">
                                <span className="material-icons-round text-yellow-400">psychology</span>
                                <h4 className="font-bold dark:text-white">Función Ejecutiva</h4>
                            </div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Ayuda a planificar, enfocar la atención y recordar instrucciones.</p>
                        </div>
                    </div>

                    {/* Text Column */}
                    <div className="order-1 md:order-2">
                        <span className="text-primary font-bold tracking-wider uppercase text-sm">Para Padres y Educadores</span>
                        <h2 className="font-display text-4xl font-bold mt-2 mb-6 text-gray-900 dark:text-white">Más que un juego, una herramienta de desarrollo</h2>
                        <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
                            Rutinario no es solo para marcar tareas. Es un sistema diseñado con psicólogos infantiles para fomentar la independencia.
                        </p>

                        <ul className="space-y-4">
                            {[
                                { title: "Reduce la ansiedad", desc: "Saber qué esperar a continuación da seguridad y calma al niño." },
                                { title: "Menos discusiones", desc: "La rutina es la autoridad, no los padres gritando órdenes." },
                                { title: "Fomenta la autonomía", desc: "El niño es responsable de voltear sus propias tarjetas." }
                            ].map((item, idx) => (
                                <li key={idx} className="flex items-start">
                                    <span className="material-icons-round text-secondary mr-3 mt-1">check_circle_outline</span>
                                    <div>
                                        <h5 className="font-bold text-gray-800 dark:text-white">{item.title}</h5>
                                        <p className="text-gray-600 dark:text-gray-400 text-sm">{item.desc}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>

                        <div className="mt-10">
                            <a href="#" className="text-primary font-bold hover:text-orange-700 dark:hover:text-orange-400 inline-flex items-center group transition">
                                Leer estudios sobre rutinas
                                <span className="material-icons-round ml-2 group-hover:translate-x-1 transition">arrow_forward</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};